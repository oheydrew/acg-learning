const cognitoSettings = {
  UserPoolId: 'us-east-1_DKIcwoZGG',
  ClientId: '5uectjtrih1d6l2fkq0pooevbj'
}

const apiGPrefix = 'https://s17drljvo9.execute-api.us-east-1.amazonaws.com/dev/'

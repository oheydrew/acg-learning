'use strict';
const querystring = require('querystring');

const prefix = process.env.HOST;

module.exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));
    console.log('URL submitted: ' + querystring.parse(event.body).link);
    callback(
        null,
        {
            statusCode: 200,
            body: `<html><body><h3>URL has been shortened: <a href="https://${prefix}/">${prefix}/</a></h3></body></html>`,
            headers: {'Content-Type': 'text/html'},
        }
    );
}
